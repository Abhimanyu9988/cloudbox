<?php 
	define("bucketName", 'cloudboxbucket1');
	define("IAM_KEY", 'AKIAUN6NNRC764RE4SPX');
	define("IAM_SECRET", '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');
 ?>